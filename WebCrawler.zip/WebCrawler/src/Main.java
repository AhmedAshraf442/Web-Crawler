import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Main {
    private static final String WIKI_URL = "https://en.wikipedia.org/wiki/List_of_pharaohs";
    private static final String SAVE_PATH = "P:\\Ahmed\\IR\\";
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "if", "in", "into", "is", "it", "no",
            "not", "of", "on", "or", "such", "that", "the", "their", "then", "there", "these", "they", "this",
            "to", "was", "will"
    ));
    private static final int MAX_LINKS = 20;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Do you want to use old fetched files or crawl new ones?");
        System.out.println("1. Use old fetched files");
        System.out.println("2. Crawl new files");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume the newline left by nextInt()

        if (choice == 1) {
            useOldFiles(scanner);
        } else if (choice == 2) {
            crawlAndSaveLinks();
            Map<String, Set<Integer>> invertedIndex = buildInvertedIndex();
            printInvertedIndex(invertedIndex);
            performQuerySearch(scanner);
        } else {
            System.out.println("Invalid choice. Please choose 1 or 2.");
        }

        scanner.close();
    }

    /**
     * Uses old fetched files, builds the inverted index, prints it, and performs query search.
     */
    private static void useOldFiles(Scanner scanner) {
        System.out.println("Using old fetched files...");
        Map<String, Set<Integer>> invertedIndex = buildInvertedIndex();
        printInvertedIndex(invertedIndex);
        performQuerySearch(scanner);
    }

    /**
     * Crawls the Wikipedia page for links, fetches content from each link, and saves it to files.
     */
    private static void crawlAndSaveLinks() {
        try {
            // Fetch the Wikipedia page
            Document doc = Jsoup.connect(WIKI_URL).get();
            Elements links = doc.select("a[href]");

            int count = 0;
            // Process each link and save the content to files
            for (Element link : links) {
                if (count >= MAX_LINKS) break;
                String url = link.absUrl("href");
                if (url.startsWith("https://en.wikipedia.org/wiki/") && !url.equals(WIKI_URL)) {
                    saveToFile(url, count + 1);
                    count++;
                }
            }

            System.out.println("Successfully fetched and saved " + count + " links.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Saves the content of a given URL to a file.
     */
    private static void saveToFile(String url, int fileNumber) {
        try {
            // Fetch the page content and save it to a file
            Document doc = Jsoup.connect(url).get();
            String text = doc.select("p").text();
            String fileName = SAVE_PATH + fileNumber + ".txt";
            FileWriter writer = new FileWriter(fileName);
            writer.write(text);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Builds an inverted index from the saved files.
     */
    private static Map<String, Set<Integer>> buildInvertedIndex() {
        File folder = new File(SAVE_PATH);
        File[] listOfFiles = folder.listFiles();
        Map<String, Set<Integer>> invertedIndex = new HashMap<>();

        // Process each file and build the inverted index
        if (listOfFiles != null && listOfFiles.length > 0) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    String fileName = file.getName();
                    List<String> words = preprocessText(file);
                    int fileId = Integer.parseInt(fileName.substring(0, fileName.lastIndexOf('.')));

                    for (String word : words) {
                        invertedIndex.computeIfAbsent(word, k -> new HashSet<>()).add(fileId);
                    }
                }
            }
        } else {
            System.out.println("No files found in the directory.");
        }
        return invertedIndex;
    }

    /**
     * Preprocesses the text from a file by tokenizing, removing stop words, and normalizing.
     */
    private static List<String> preprocessText(File file) {
        List<String> words = new ArrayList<>();
        try {
            String text = new String(Files.readAllBytes(Paths.get(file.getPath())));
            String[] tokens = text.replaceAll("[^a-zA-Z0-9\\s]", "").toLowerCase().split("\\s+");
            for (String token : tokens) {
                if (token.length() > 2 && !STOP_WORDS.contains(token)) {
                    words.add(token);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return words;
    }

    /**
     * Performs a query search by calculating cosine similarity between the query and each document.
     */
    private static void performQuerySearch(Scanner scanner) {
        System.out.println("Enter your query:");
        String query = scanner.nextLine().toLowerCase();
        Map<Integer, Double> similarityScores = calculateCosineSimilarity(query);
        printTopSimilarFiles(similarityScores);
    }

    /**
     * Calculates the cosine similarity between the query and each document.
     */
    private static Map<Integer, Double> calculateCosineSimilarity(String query) {
        Map<Integer, List<String>> fileWordsMap = new HashMap<>();
        Map<Integer, Double> similarityScores = new HashMap<>();

        File folder = new File(SAVE_PATH);
        File[] listOfFiles = folder.listFiles();
        if (listOfFiles != null && listOfFiles.length > 0) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    List<String> words = preprocessText(file);
                    int fileId = Integer.parseInt(file.getName().substring(0, file.getName().lastIndexOf('.')));
                    fileWordsMap.put(fileId, words);
                }
            }
        }

        List<String> queryWords = preprocessQuery(query);
        for (Map.Entry<Integer, List<String>> entry : fileWordsMap.entrySet()) {
            List<String> words = entry.getValue();
            double similarity = calculateCosineSimilarity(queryWords, words);
            similarityScores.put(entry.getKey(), similarity);
        }

        return sortByValue(similarityScores);
    }

    /**
     * Calculates the cosine similarity between the query words and document words.
     */
    private static double calculateCosineSimilarity(List<String> queryWords, List<String> documentWords) {
        Set<String> allWords = new HashSet<>(queryWords);
        allWords.addAll(documentWords);

        Map<String, Integer> queryVector = new HashMap<>();
        Map<String, Integer> documentVector = new HashMap<>();

        for (String word : allWords) {
            queryVector.put(word, Collections.frequency(queryWords, word));
            documentVector.put(word, Collections.frequency(documentWords, word));
        }

        int dotProduct = 0;
        double queryNorm = 0.0;
        double documentNorm = 0.0;

        for (String word : allWords) {
            int queryFrequency = queryVector.getOrDefault(word, 0);
            int documentFrequency = documentVector.getOrDefault(word, 0);

            dotProduct += queryFrequency * documentFrequency;
            queryNorm += Math.pow(queryFrequency, 2);
            documentNorm += Math.pow(documentFrequency, 2);
        }

        queryNorm = Math.sqrt(queryNorm);
        documentNorm = Math.sqrt(documentNorm);

        if (queryNorm == 0.0 || documentNorm == 0.0) {
            return 0.0;
        }

        return dotProduct / (queryNorm * documentNorm);
    }

    /**
     * Preprocesses the query text by tokenizing, removing stop words, and normalizing.
     */
    private static List<String> preprocessQuery(String query) {
        List<String> words = new ArrayList<>();
        String[] tokens = query.replaceAll("[^a-zA-Z0-9\\s]", "").toLowerCase().split("\\s+");
        for (String token : tokens) {
            if (token.length() > 2 && !STOP_WORDS.contains(token)) {
                words.add(token);
            }
        }
        return words;
    }

    /**
     * Prints the inverted index.
     */
    private static void printInvertedIndex(Map<String, Set<Integer>> invertedIndex) {
        System.out.println("Inverted Index:");
        for (Map.Entry<String, Set<Integer>> entry : invertedIndex.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }

    /**
     * Prints the top 10 files with the highest similarity scores.
     */
    private static void printTopSimilarFiles(Map<Integer, Double> similarityScores) {
        System.out.println("Top 10 files with highest similarity scores:");
        int count = 0;
        for (Map.Entry<Integer, Double> entry : similarityScores.entrySet()) {
            System.out.println("File: " + entry.getKey() + ", Similarity Score: " + entry.getValue());
            count++;
            if (count >= 10) break;
        }
    }

    /**
     * Sorts a map by its values in descending order.
     */
    private static Map<Integer, Double> sortByValue(Map<Integer, Double> map) {
        List<Map.Entry<Integer, Double>> list = new LinkedList<>(map.entrySet());
        list.sort((o1, o2) -> (o2.getValue()).compareTo(o1.getValue()));

        Map<Integer, Double> result = new LinkedHashMap<>();
        for (Map.Entry<Integer, Double> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }
}
